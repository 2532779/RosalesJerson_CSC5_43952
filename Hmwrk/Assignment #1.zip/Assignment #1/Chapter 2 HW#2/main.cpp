/* 
 * File:   Program for problem number 2!
 * Author: Jerson Rosales
 * Created on February 22, 2015, 1:46 PM
 */

#include <iostream>
using namespace std;
//User Libraries

//Global Constants
unsigned char CNVPCT=100;

//Function Prototypes

//Execution Begins 

int main(int argc, char** argv) {
   
    float ttlGnd, // Total Sales Gained
           sls = 8.6e6, // Sales Made in one year
           slsGnd = 58 ; // Percentage of sales actually made
    
    ttlGnd = sls * slsGnd/CNVPCT;
    
        cout << "With a 58 percent sales gain, the East Coast \n";
            cout << "Division makes with 8.6 million $, a total of\n";
             cout << ttlGnd << "$!" << endl;   
    
     return 0;
}

