/* 
 * File:   main.cpp
 * Author: Jerson Rosales
 * Created on March 4, 2015, 9:39 AM
 * Purpose: Homework number 9
 */

#include <iostream>

using namespace std;

//User libraries

//Global Constants

//Function Prototypes

//Execution Begins


int main(int argc, char** argv) {
    // I Dont have to declare variables!Because im only naming sizeof 
    //data types!
    cout<<"The amount the data type 'char' has is "<< sizeof(char)<<
            " byte."<<endl;
    cout<<"The amount the data type 'int'has is "<< sizeof(int)<<
            " bytes."<<endl;
    cout<<"The amount the data type 'float' has is "<< sizeof(float)<<
            " bytes."<<endl;
    cout<<"The amount of data type 'double'has is "<< sizeof(double)<<
            " bytes."<<endl;

    return 0;
}

