/* 
 * File: main.cpp
 * Author: Jerson Rosales
 * Created on February 22, 2015, 1:28 PM
 * Purpose: Problem number 1 
 */

#include <iostream>

using namespace std;
int main(int argc, char** argv) {
    unsigned short apls, bnans, total;// Variables are Apples and bannanas 
    apls = 50;
    bnans = 100;
    total = apls + bnans;
    cout << "The sum of 50 apples and 100 bannanas is " << total << endl;
    cout << "apples and bannanas." << endl;
         

    return 0;
}

