/* 
 * File:   main.cpp
 * Author: Jerson Rosales
 * Created on February 18, 2015, 9:55 AM
 *      Purpose: Our first program!
 */

//System Libraries
#include <iostream>//Input/Output Library
using namespace std;//Standard namespace for the I/O stream Library

//User Libraries

//Global Constants 

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv) {
    //Output Hello World
    cout<<"Hello World"<<endl;
    //Exit stage right!
    return 0;
}

